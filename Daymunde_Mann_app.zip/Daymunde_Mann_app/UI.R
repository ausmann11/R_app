library(shiny)
library(shinyWidgets)

shinyUI(fluidPage(
  titlePanel("Mortality in LA following Colorectal Cancer Diagnosis"),
  setBackgroundImage(src="https://media.istockphoto.com/vectors/strong-healthy-happy-intestine-character-vector-id861361456?k=6&m=861361456&s=612x612&w=0&h=vZ4xhIvmWHp0cqtfVyw2hDJylF8VPijo20j7yPSelzc="),
  sidebarLayout(
    sidebarPanel(
      helpText("Display survival probability curves based on user input."),
      selectInput("spt",label="Parish of Residence",
                  choices=sort(c("Calcasieu","Union","Tangipahoa","Caldwell","Tensas","Jackson",
                                 "Grant","Lincoln","Jefferson Davis","Lafayette","Vermilion",
                                 "East Carroll","East Feliciana","St. Bernard","Iberville","Richland",
                                 "St. Martin","Claiborne","Evangeline","St. Landry","Pointe Coupee",
                                 "LaSalle","Webster","St. James","Plaquemines","Morehouse","Rapides",
                                 "Avoyelles","Winn","Vernon","Catahoula","Assumption","De Soto",
                                 "Caddo","Red River","Washington","Sabine","Jefferson","St. Tammany",
                                 "Cameron","East Baton Rouge","Iberia","Natchitoches","Terrebonne",
                                 "Bienville","Bossier","Allen","Ouachita","St. John the Baptist",
                                 "St. Helena","West Feliciana","St. Mary","Lafourche","West Carroll",
                                 "Concordia","Livingston","West Baton Rouge","Madison","Orleans",
                                 "Ascension","Acadia","St. Charles","Beauregard","Franklin"))),
      sliderInput("agedx",label="Enter your age at diagnosis",value=50,min=1,max=100),
      checkboxInput('gender',label="Is the patient male?",value=FALSE),
      checkboxInput("race",label="Is the patient white?",value=FALSE),
      selectInput("married",label="Marital Status at Diagnosis",
                  choices=list("Single","Currently Married","Previously Married","Other"),selected="Single"),
      helpText("Note: 'currently married' includes life or domestic partners."),
      sliderInput("year",label='What year were you diagnosed?',
                  value=2005,step=1,min=2000,max=2013,sep=""),
      checkboxInput("previous",label="Had previous tumor",value=FALSE),
      selectInput("grade",
                    label="Select if your cancer was considered high grade",
                    choices=list("Yes","No","Unkown"),selected="Unkown"),
      radioButtons("surg",label="Was surgery performed?",
                  choices=list("Yes","No","Unknown"),selected="No"),
      selectInput("rad",label="Was radiation therapy performed?",
                  choices=list("Yes","No","Unknown"),selected="No"),
      submitButton("Calculate Survival Probability")
    ),
    mainPanel(
      textOutput("text"),
      plotOutput("survplot"),
      tableOutput("tab"),
      textOutput(("text2"))
    )
  )
))