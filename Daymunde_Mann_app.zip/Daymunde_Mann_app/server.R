library(shiny)
t=c(1.01,2:160)
modelAFT=list(summary=1)
modelAFT$summary=read.csv("C:\\Users\\sam2146\\Documents\\DSC_551\\modelTcrca.csv",header=FALSE)[,-1]
u=modelAFT$summary[3:66]
gamma=modelAFT$summary[82:95]
map=read.csv("C:\\Users\\sam2146\\Documents\\DSC_551\\LAcountyORDER.csv")

shinyServer(function(input,output){
  output$text <- renderText({
    paste("The plot below displays the survival probability curve for colorectal cancer related mortality
         following colorectal cancer diagnosis for a ",input$agedx," year old ",
          ifelse(input$race==TRUE,"White","non-White"),
          ifelse(input$gender==TRUE,"male","female"),
          " that resided in ",input$spt, " Parish",
          ifelse(input$married=="Single"," and was single",
                 ifelse(input$married=="Currently Married"," and was currently married",
                        ifelse(input$married=="Previously Married"," and was previously married",""))),
          " at the time of diagnosis. Their cancer was considered ",
          ifelse(input$grade=='Yes',"high grade",
                 ifelse(input$grade == 'No', 'low grade',
                        'unknown')),
          "grade with ",
          ifelse(input$previous==TRUE,"previous tumors.","no previous tumors."),
          ifelse(input$rad=="Yes","Radiation therapy was performed",
                 ifelse(input$rad=="No","Radiation therapy was performed",
                        "It is unknown if radiation therapy was performed")),
          " and ",
          ifelse(input$surg=="Yes","surgery was performed.",
                 ifelse(input$surg=="No","surgery was not performed.",
                        "it is unknown if surgery was performed.")))
  })
  output$survplot <- renderPlot({
    sptnum=map$order[which(map$NAME==input$spt)]
    survprob=1/(1+(exp(-(modelAFT$summary[68]+
                           modelAFT$summary[69]*(input$agedx-61.45055)/13.6418+
                           ifelse(input$race==TRUE,modelAFT$summary[70],0)+
                           ifelse(input$gender==TRUE,modelAFT$summary[80],0)+
                           ifelse(input$grade=="high",modelAFT$summary[71],
                                  ifelse(input$grade=="unkown",0,modelAFT$summary[72]))+
                           ifelse(input$surg=="Yes",modelAFT$summary[73],
                                  ifelse(input$surg=="No",0,modelAFT$summary[74]))+
                           ifelse(input$married=="Single",0,
                                  ifelse(input$married=="Currently Married",modelAFT$summary[75],
                                         ifelse(input$married=="Previously Married",
                                                modelAFT$summary[76],modelAFT$summary[77])))+
                           ifelse(input$previous==TRUE,modelAFT$summary[81],0)+
                           ifelse(input$rad=="Yes",modelAFT$summary[78],
                                  ifelse(input$rad=="No",0,modelAFT$summary[79]))+
                           u[sptnum]+gamma[input$year-1999]))*t)^(1/modelAFT$summary[2]))
    plot(survprob~t,ylab="Survival Probability",type="l",xlab="Months",
         ylim=c(0,1),main="")
  },bg="transparent")
output$tab <- renderTable({
    sptnum=map$order[which(map$NAME==input$spt)]
    survprob=1/(1+(exp(-(modelAFT$summary[68]+
                           modelAFT$summary[69]*(input$agedx-61.45055)/13.6418+
                           ifelse(input$race==TRUE,modelAFT$summary[70],0)+
                           ifelse(input$gender==TRUE,modelAFT$summary[80],0)+
                           ifelse(input$grade=="high",modelAFT$summary[71],
                                  ifelse(input$grade=="unkown",0,modelAFT$summary[72]))+
                           ifelse(input$surg=="Yes",modelAFT$summary[73],
                                  ifelse(input$surg=="No",0,modelAFT$summary[74]))+
                           ifelse(input$married=="Single",0,
                                  ifelse(input$married=="Currently Married",modelAFT$summary[75],
                                         ifelse(input$married=="Previously Married",
                                                modelAFT$summary[76],modelAFT$summary[77])))+
                           ifelse(input$previous==TRUE,modelAFT$summary[81],0)+
                           ifelse(input$rad=="Yes",modelAFT$summary[78],
                                  ifelse(input$rad=="No",0,modelAFT$summary[79]))+
                           u[sptnum]+gamma[input$year-1999]))*c(12,24,60))^(1/modelAFT$summary[2]))
    data <- matrix(survprob,nrow=1,ncol=3,dimnames=list(list(),list("Survival Probabilty at 1 year",
                                                                    "Survival Probability at 2 years","Survival Probability at 5 years")))
  })
output$text2 <- renderText({
  paste("Particular Parishes have positive or negative effects on survival probability. As a persons age increases their 
        survival probablility decreases. Male patients are less likely to survive than females. If a person is white they have a 
        higher probability than if they are of another race. A person who is married has a stronger chance of survival than 
        someone who is divoreced, but they are both more likely to survive than someone who is single. The year of diagnosis can 
        also have an effect on someones survival probability. A person who has had a previous tumor is more likely to survive.
        If the cancer is high grade they are less likely to survive. Surgery and radiation also increase the patients survivail 
        probability.")
})
})
